import {
  IsString,
  IsNotEmpty,
  IsNumber,
  IsDateString,
  IsOptional,
  IsUUID,
  IsInt,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateProductDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  product_name: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  product_description: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  product_type: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  product_brand: string;


  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  product_price: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  product_rating: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  product_stock: number;
}
