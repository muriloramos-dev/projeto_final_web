import { Inject, Injectable } from '@nestjs/common';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { PrismaService } from 'src/prisma/prisma.service';
import { ProductType } from '@prisma/client';
import { ClientProxy, MessagePattern } from '@nestjs/microservices';

@Injectable()
export class ProductService {
  constructor(private prisma: PrismaService, @Inject("PRODUCT_SERVICE") private readonly client: ClientProxy) {}

  async create(createProductDto: CreateProductDto) {
    const upperType = createProductDto.product_type.toUpperCase();

    if (!(upperType in ProductType)) {
      throw new Error(`Invalid product type: ${createProductDto.product_type}`);
    }
    const productType = ProductType[upperType as keyof typeof ProductType];

    await this.prisma.product.create({
      data: {
        description: createProductDto.product_description,
        name: createProductDto.product_name,
        price: createProductDto.product_price,
        rating: createProductDto.product_rating,
        stock: createProductDto.product_stock,
        type: productType,
        brand: createProductDto.product_brand,
      },
    });

    return { message: 'Product created successfully' };
  }

  async findAll(page: number = 1, limit: number = 100) {
    const skip = (page - 1) * limit;
    return this.prisma.product.findMany({
      skip,
      take: limit,
    });
  }

  async findAllByIds(items: string[]) {
    if (items.length === 0) {
      return [];
    }

    return this.prisma.product.findMany({
      where: {
        id: {
          in: items,
        },
      },
    });
  }

  async findByType(
    productType: string,
    page: number = 1,
    limit: number = 9,
  ) {
    const skip = (page - 1) * limit;

    const upperType = productType.toUpperCase();
    if (!(upperType in ProductType)) {
      throw new Error(`Invalid product type: ${productType}`);
    }

    return await this.prisma.product.findMany({
      where: {
        type: ProductType[upperType as keyof typeof ProductType],
      },
      skip,
      take: limit,
    });
  }

  async findAllByBrand(brand: string, page: number = 1) {
    const limit: number = 9;
    const skip = (page - 1) * limit;

    return await this.prisma.product.findMany({
      where: {
        brand: brand,
      },
      skip,
      take: limit,
    });
  }

  async findOne(id: string) {
    return await this.prisma.product.findUnique({
      where: {
        id: id,
      },
    });
  }

  async update(id: string, updateProductDto: UpdateProductDto) {
    let productType: ProductType | undefined;

    if (updateProductDto.product_type) {
      const upperType = updateProductDto.product_type.toUpperCase();
      if (!(upperType in ProductType)) {
        throw new Error(`Invalid product type: ${updateProductDto.product_type}`);
      }
      productType = ProductType[upperType as keyof typeof ProductType];
    }

    const prismaData = {
      name: updateProductDto.product_name,
      description: updateProductDto.product_description,
      price: updateProductDto.product_price,
      rating: updateProductDto.product_rating,
      stock: updateProductDto.product_stock,
      type: productType,
      brand: updateProductDto.product_brand,
    };

    Object.keys(prismaData).forEach(
      (key) => prismaData[key] === undefined && delete prismaData[key],
    );

    return await this.prisma.product.update({
      where: { id },
      data: prismaData,
    });
  }

  async remove(id: string) {
    return await this.prisma.product.delete({
      where: { id },
    });
  }
}
