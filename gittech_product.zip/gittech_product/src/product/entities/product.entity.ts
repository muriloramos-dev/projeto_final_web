import { ApiProperty } from '@nestjs/swagger';

export class Product {
  @ApiProperty()
  product_id: string;

  @ApiProperty()
  product_name: string;

  @ApiProperty()
  product_description: string;

  @ApiProperty()
  product_type: string;

  @ApiProperty()
  product_price: number;

  @ApiProperty()
  created_at: string;

  @ApiProperty({ required: false })
  updated_at?: string;

  @ApiProperty()
  product_rating: number;

  @ApiProperty()
  product_stock: number;
}
