// export interface ProductType {
//     CELULAR,
//     NOTEBOOK,
//     LAPTOP,
//     TV,
//     HARDWARE,
//     PERIFERICOS,
//     ACESSORIOS

//     function getType() {

//     }
// }