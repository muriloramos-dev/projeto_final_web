import { Controller } from '@nestjs/common';
import { EventPattern, Payload } from '@nestjs/microservices';
import { ProductService } from './product.service';

@Controller()
export class ProductEventsController {
  constructor(private readonly productService: ProductService) {}

  @EventPattern('stock.reserve')
  async handleStockReserve(@Payload() data: { productId: string; quantity: number }) {
    console.log('Received stock.reserve event:', data);
    // TODO: Implement stock reservation logic
    // await this.productService.reserveStock(data.productId, data.quantity);
  }

  @EventPattern('stock.release')
  async handleStockRelease(@Payload() data: { productId: string; quantity: number }) {
    console.log('Received stock.release event:', data);
    // TODO: Implement stock release logic
    // await this.productService.releaseStock(data.productId, data.quantity);
  }
}
