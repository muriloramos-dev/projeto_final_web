create table Product (
	product_id CHAR(36),
    product_name varchar(255) NOT NULL,
	product_description varchar(255) NOT NULL,
    product_type varchar(255) NOT NULL,
    product_price DECIMAL NOT NULL,
    created_at DATE NOT NULL,
    updated_at DATE,
    product_rating FLOAT NOT NULL,
    product_stock INT NOT NULL,
    PRIMARY KEY (product_id),
    cart_id CHAR(36),
    FOREIGN KEY (cart_id) REFERENCES Cart(cart_id)
);