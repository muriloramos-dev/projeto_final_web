-- AlterTable
ALTER TABLE `Product` ADD COLUMN `product_image` VARCHAR(191) NULL;
