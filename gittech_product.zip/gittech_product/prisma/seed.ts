import { PrismaClient, ProductType } from '../generated/prisma';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding product database...');

  // ----------------------------------------------------------------------------------
  // CONTEÚDO NOVO: Combinação das listas 'products' e 'additionalProducts' com a correção de caracteres
  // ----------------------------------------------------------------------------------
  const additionalProducts = [
    // Celulares (15 produtos)
    { name: 'iPhone 14 Pro 256GB', description: 'iPhone 14 Pro com Dynamic Island, câmera de 48MP e chip A16 Bionic', type: ProductType.CELULAR, brand: 'Apple', price: 6999.00, rating: 4.7, stock: 40 },
    { name: 'iPhone 13 128GB', description: 'iPhone 13 com chip A15 Bionic, câmera dupla de 12MP e tela Super Retina XDR', type: ProductType.CELULAR, brand: 'Apple', price: 4999.00, rating: 4.6, stock: 60 },
    { name: 'Samsung Galaxy S23 256GB', description: 'Galaxy S23 com processador Snapdragon 8 Gen 2, câmera de 50MP e tela AMOLED', type: ProductType.CELULAR, brand: 'Samsung', price: 4799.00, rating: 4.6, stock: 50 },
    { name: 'Samsung Galaxy A54 128GB', description: 'Galaxy A54 com tela Super AMOLED de 6.4", câmera tripla de 50MP e bateria de 5000mAh', type: ProductType.CELULAR, brand: 'Samsung', price: 2299.00, rating: 4.4, stock: 80 },
    { name: 'Xiaomi Redmi Note 13 Pro', description: 'Redmi Note 13 Pro com câmera de 200MP, carregamento rápido de 67W e tela AMOLED', type: ProductType.CELULAR, brand: 'Xiaomi', price: 2199.00, rating: 4.5, stock: 90 },
    { name: 'Motorola Edge 40 Pro', description: 'Edge 40 Pro com Snapdragon 8 Gen 2, câmera de 50MP e carregamento sem fio', type: ProductType.CELULAR, brand: 'Motorola', price: 3999.00, rating: 4.5, stock: 45 },
    { name: 'Google Pixel 8 Pro', description: 'Pixel 8 Pro com Google Tensor G3, câmera de 50MP e Magic Eraser', type: ProductType.CELULAR, brand: 'Google', price: 5999.00, rating: 4.7, stock: 35 },
    { name: 'OnePlus 11 256GB', description: 'OnePlus 11 com Snapdragon 8 Gen 2, carregamento de 100W e tela AMOLED 120Hz', type: ProductType.CELULAR, brand: 'OnePlus', price: 4499.00, rating: 4.6, stock: 40 },
    { name: 'Asus Zenfone 10', description: 'Zenfone 10 compacto com Snapdragon 8 Gen 2, câmera de 50MP e estabilização gimbal', type: ProductType.CELULAR, brand: 'Asus', price: 4299.00, rating: 4.5, stock: 30 },
    { name: 'Sony Xperia 1 V', description: 'Xperia 1 V com tela 4K OLED, câmera Zeiss e áudio Hi-Res', type: ProductType.CELULAR, brand: 'Sony', price: 6499.00, rating: 4.6, stock: 25 },
    { name: 'Realme GT 3', description: 'Realme GT 3 com carregamento de 240W, Snapdragon 8+ Gen 1 e tela AMOLED', type: ProductType.CELULAR, brand: 'Realme', price: 3299.00, rating: 4.4, stock: 55 },
    { name: 'Nothing Phone 2', description: 'Nothing Phone 2 com Glyph Interface, Snapdragon 8+ Gen 1 e design único', type: ProductType.CELULAR, brand: 'Nothing', price: 3799.00, rating: 4.5, stock: 40 },
    { name: 'Vivo X90 Pro', description: 'Vivo X90 Pro com câmera Zeiss, MediaTek Dimensity 9200 e carregamento de 120W', type: ProductType.CELULAR, brand: 'Vivo', price: 5299.00, rating: 4.6, stock: 30 },
    { name: 'Oppo Find X6 Pro', description: 'Find X6 Pro com câmera Hasselblad, Snapdragon 8 Gen 2 e tela AMOLED 120Hz', type: ProductType.CELULAR, brand: 'Oppo', price: 5499.00, rating: 4.6, stock: 28 },
    { name: 'Honor Magic 5 Pro', description: 'Magic 5 Pro com Snapdragon 8 Gen 2, câmera tripla de 50MP e bateria de 5100mAh', type: ProductType.CELULAR, brand: 'Honor', price: 4799.00, rating: 4.5, stock: 35 },

    // Notebooks (15 produtos)
    { name: 'ASUS ROG Zephyrus G14', description: 'ROG Zephyrus G14 com Ryzen 9, RTX 4060, 16GB RAM e tela QHD 165Hz', type: ProductType.NOTEBOOK, brand: 'Asus', price: 9999.00, rating: 4.7, stock: 20 },
    { name: 'MSI Stealth 15M', description: 'MSI Stealth 15M com Intel i7, RTX 4050, 16GB RAM e design ultrafino', type: ProductType.NOTEBOOK, brand: 'MSI', price: 7999.00, rating: 4.5, stock: 25 },
    { name: 'Acer Predator Helios 300', description: 'Predator Helios 300 com Intel i7, RTX 4060, 16GB RAM e tela 144Hz', type: ProductType.NOTEBOOK, brand: 'Acer', price: 8499.00, rating: 4.6, stock: 30 },
    { name: 'HP Omen 16', description: 'HP Omen 16 com Intel i7, RTX 4070, 32GB RAM e tela QHD 165Hz', type: ProductType.NOTEBOOK, brand: 'HP', price: 10999.00, rating: 4.6, stock: 18 },
    { name: 'Razer Blade 15', description: 'Razer Blade 15 com Intel i9, RTX 4080, 32GB RAM e tela QHD 240Hz', type: ProductType.NOTEBOOK, brand: 'Razer', price: 18999.00, rating: 4.8, stock: 10 },
    { name: 'Lenovo Legion 7i', description: 'Legion 7i com Intel i9, RTX 4080, 32GB RAM e sistema de refrigeração avançado', type: ProductType.NOTEBOOK, brand: 'Lenovo', price: 16999.00, rating: 4.7, stock: 12 },
    { name: 'Alienware m15 R7', description: 'Alienware m15 R7 com Intel i7, RTX 4070, 16GB RAM e design icônico', type: ProductType.NOTEBOOK, brand: 'Dell', price: 13999.00, rating: 4.7, stock: 15 },
    { name: 'Gigabyte Aorus 15', description: 'Aorus 15 com Intel i7, RTX 4060, 16GB RAM e teclado mecânico', type: ProductType.NOTEBOOK, brand: 'Gigabyte', price: 9499.00, rating: 4.5, stock: 22 },
    { name: 'Microsoft Surface Laptop 5', description: 'Surface Laptop 5 com Intel i7, 16GB RAM, SSD 512GB e tela PixelSense', type: ProductType.NOTEBOOK, brand: 'Microsoft', price: 8999.00, rating: 4.6, stock: 28 },
    { name: 'LG Gram 17', description: 'LG Gram 17 ultraleve com Intel i7, 16GB RAM, SSD 1TB e bateria de longa duração', type: ProductType.NOTEBOOK, brand: 'LG', price: 9999.00, rating: 4.5, stock: 20 },
    { name: 'Samsung Galaxy Book3 Pro', description: 'Galaxy Book3 Pro com Intel i7, 16GB RAM, tela AMOLED e design premium', type: ProductType.NOTEBOOK, brand: 'Samsung', price: 10499.00, rating: 4.6, stock: 18 },
    { name: 'Acer Swift X', description: 'Swift X com Ryzen 7, RTX 3050, 16GB RAM e design compacto', type: ProductType.NOTEBOOK, brand: 'Acer', price: 5999.00, rating: 4.4, stock: 35 },
    { name: 'Asus VivoBook Pro 15', description: 'VivoBook Pro 15 com Intel i7, RTX 3050, 16GB RAM e tela OLED', type: ProductType.NOTEBOOK, brand: 'Asus', price: 6499.00, rating: 4.5, stock: 30 },
    { name: 'HP Pavilion Gaming', description: 'Pavilion Gaming com Ryzen 5, GTX 1650, 8GB RAM e design gamer acessível', type: ProductType.NOTEBOOK, brand: 'HP', price: 4299.00, rating: 4.3, stock: 40 },
    { name: 'Lenovo IdeaPad Gaming 3', description: 'IdeaPad Gaming 3 com Ryzen 5, RTX 3050, 8GB RAM e tela 120Hz', type: ProductType.NOTEBOOK, brand: 'Lenovo', price: 4799.00, rating: 4.4, stock: 38 },

    // TVs (10 produtos)
    { name: 'Sony Bravia XR A95K 65"', description: 'TV OLED Sony 65" 4K com QD-OLED, Cognitive Processor XR e Google TV', type: ProductType.TV, brand: 'Sony', price: 12999.00, rating: 4.9, stock: 8 },
    { name: 'TCL C835 75"', description: 'Smart TV TCL 75" Mini LED 4K com QLED, 144Hz e Google TV', type: ProductType.TV, brand: 'TCL', price: 6999.00, rating: 4.5, stock: 15 },
    { name: 'Philips OLED+ 55"', description: 'TV OLED Philips 55" 4K com Ambilight, P5 AI e som Bowers & Wilkins', type: ProductType.TV, brand: 'Philips', price: 7499.00, rating: 4.6, stock: 12 },
    { name: 'Hisense U8H 65"', description: 'Smart TV Hisense 65" Mini LED 4K com Quantum Dot e 120Hz', type: ProductType.TV, brand: 'Hisense', price: 5499.00, rating: 4.5, stock: 18 },
    { name: 'Panasonic LZ2000 55"', description: 'TV OLED Panasonic 55" 4K com Master HDR e HCX Pro AI', type: ProductType.TV, brand: 'Panasonic', price: 8999.00, rating: 4.7, stock: 10 },
    { name: 'Samsung Neo QLED 8K 75"', description: 'Smart TV Samsung 75" Neo QLED 8K com Neural Quantum Processor', type: ProductType.TV, brand: 'Samsung', price: 19999.00, rating: 4.8, stock: 5 },
    // PRODUTO CORRIGIDO: Substituindo 'α7' por 'Alpha 7'
    { name: 'LG NanoCell 65"', description: 'Smart TV LG 65" NanoCell 4K com Alpha 7 Gen5 e webOS', type: ProductType.TV, brand: 'LG', price: 4299.00, rating: 4.4, stock: 22 },
    { name: 'Sony X90K 55"', description: 'Smart TV Sony 55" LED 4K com XR Triluminos Pro e Google TV', type: ProductType.TV, brand: 'Sony', price: 4999.00, rating: 4.6, stock: 20 },
    { name: 'Samsung The Frame 55"', description: 'Smart TV Samsung 55" QLED 4K com design de quadro e Art Mode', type: ProductType.TV, brand: 'Samsung', price: 6499.00, rating: 4.7, stock: 15 },
    { name: 'LG C2 42"', description: 'TV OLED LG 42" 4K ideal para gaming com 120Hz e G-Sync', type: ProductType.TV, brand: 'LG', price: 5499.00, rating: 4.8, stock: 18 },

    // Hardwares (10 produtos)
    { name: 'Intel Core i7-13700K', description: 'Processador Intel Core i7-13700K com 16 núcleos, 24 threads e 5.4GHz turbo', type: ProductType.HARDWARE, brand: 'Intel', price: 2499.00, rating: 4.7, stock: 25 },
    { name: 'AMD Ryzen 7 7800X3D', description: 'Processador AMD Ryzen 7 7800X3D com 8 núcleos e tecnologia 3D V-Cache', type: ProductType.HARDWARE, brand: 'AMD', price: 2899.00, rating: 4.8, stock: 20 },
    { name: 'NVIDIA RTX 4070 Ti', description: 'Placa de vídeo NVIDIA RTX 4070 Ti com 12GB GDDR6X e DLSS 3', type: ProductType.HARDWARE, brand: 'NVIDIA', price: 5999.00, rating: 4.7, stock: 18 },
    { name: 'AMD Radeon RX 7800 XT', description: 'Placa de vídeo AMD RX 7800 XT com 16GB GDDR6 e FSR 3', type: ProductType.HARDWARE, brand: 'AMD', price: 4299.00, rating: 4.6, stock: 22 },
    { name: 'G.Skill Trident Z5 RGB 32GB', description: 'Memória RAM G.Skill DDR5 32GB (2x16GB) 6400MHz CL32 com RGB', type: ProductType.HARDWARE, brand: 'G.Skill', price: 1499.00, rating: 4.6, stock: 30 },
    { name: 'Kingston Fury Beast 16GB', description: 'Memória RAM Kingston DDR4 16GB 3200MHz CL16', type: ProductType.HARDWARE, brand: 'Kingston', price: 399.00, rating: 4.5, stock: 50 },
    { name: 'Samsung 990 Pro 2TB', description: 'SSD NVMe Samsung 990 Pro 2TB PCIe 4.0 com leitura de 7450MB/s', type: ProductType.HARDWARE, brand: 'Samsung', price: 1299.00, rating: 4.8, stock: 35 },
    { name: 'WD Black SN850X 1TB', description: 'SSD NVme WD Black SN850X 1TB PCIe 4.0 para gaming', type: ProductType.HARDWARE, brand: 'Western Digital', price: 799.00, rating: 4.7, stock: 40 },
    { name: 'ASUS ROG Strix B650E-E', description: 'Placa-mãe ASUS ROG Strix B650E-E ATX AM5 com PCIe 5.0', type: ProductType.HARDWARE, brand: 'Asus', price: 2299.00, rating: 4.6, stock: 15 },
    { name: 'MSI MAG B760 Tomahawk', description: 'Placa-mãe MSI MAG B760 Tomahawk ATX LGA1700 com DDR5', type: ProductType.HARDWARE, brand: 'MSI', price: 1799.00, rating: 4.5, stock: 20 },

    // Periféricos (10 produtos)
    { name: 'Razer DeathAdder V3 Pro', description: 'Mouse gamer sem fio Razer com sensor Focus Pro 30K e 90h de bateria', type: ProductType.PERIFERICOS, brand: 'Razer', price: 899.00, rating: 4.7, stock: 35 },
    { name: 'Logitech G915 TKL', description: 'Teclado mecânico sem fio Logitech com switches GL e RGB', type: ProductType.PERIFERICOS, brand: 'Logitech', price: 1499.00, rating: 4.6, stock: 25 },
    { name: 'SteelSeries Arctis Nova Pro', description: 'Headset gamer SteelSeries com DAC Hi-Res e cancelamento de ruído', type: ProductType.PERIFERICOS, brand: 'SteelSeries', price: 2299.00, rating: 4.8, stock: 20 },
    { name: 'Corsair K70 RGB Pro', description: 'Teclado mecânico Corsair com switches Cherry MX e RGB dinâmico', type: ProductType.PERIFERICOS, brand: 'Corsair', price: 1199.00, rating: 4.6, stock: 30 },
    { name: 'HyperX Pulsefire Haste 2', description: 'Mouse gamer ultraleve HyperX com 53g e sensor 26K', type: ProductType.PERIFERICOS, brand: 'HyperX', price: 399.00, rating: 4.5, stock: 45 },
    { name: 'Razer Huntsman V2', description: 'Teclado óptico Razer com switches ópticos e apoio de pulso', type: ProductType.PERIFERICOS, brand: 'Razer', price: 1399.00, rating: 4.7, stock: 28 },
    { name: 'Logitech StreamCam', description: 'Webcam Logitech Full HD 1080p 60fps com USB-C', type: ProductType.PERIFERICOS, brand: 'Logitech', price: 899.00, rating: 4.5, stock: 40 },
    { name: 'Blue Yeti X', description: 'Microfone condensador Blue Yeti X com LED e controles inteligentes', type: ProductType.PERIFERICOS, brand: 'Blue', price: 1299.00, rating: 4.7, stock: 25 },
    { name: 'Elgato Stream Deck MK.2', description: 'Stream Deck Elgato com 15 teclas LCD personalizáveis', type: ProductType.PERIFERICOS, brand: 'Elgato', price: 1099.00, rating: 4.8, stock: 22 },
    { name: 'Corsair HS80 RGB Wireless', description: 'Headset sem fio Corsair com som espacial Dolby Atmos', type: ProductType.PERIFERICOS, brand: 'Corsair', price: 899.00, rating: 4.6, stock: 32 },

    // Acessórios (8 produtos adicionais)
    { name: 'Apple Watch Ultra 2', description: 'Apple Watch Ultra 2 com GPS + Cellular, caixa de titânio e tela maior', type: ProductType.ACESSORIOS, brand: 'Apple', price: 7499.00, rating: 4.9, stock: 30 },
    { name: 'Carregador Anker GaNPrime 100W', description: 'Carregador de parede Anker GaNPrime de 100W com 3 portas', type: ProductType.ACESSORIOS, brand: 'Anker', price: 499.00, rating: 4.7, stock: 150 },
    { name: 'Cabo USB-C Thunderbolt 4', description: 'Cabo USB-C Thunderbolt 4 de 2m com 40Gbps de velocidade', type: ProductType.ACESSORIOS, brand: 'Belkin', price: 399.00, rating: 4.8, stock: 200 },
    { name: 'Baseus Power Bank 20000mAh', description: 'Power Bank Baseus 20000mAh com carregamento rápido de 65W', type: ProductType.ACESSORIOS, brand: 'Baseus', price: 599.00, rating: 4.6, stock: 100 },
    { name: 'Suporte de Monitor Dual Articulado', description: 'Suporte de mesa para dois monitores com braços articulados', type: ProductType.ACESSORIOS, brand: 'ELG', price: 799.00, rating: 4.5, stock: 80 },
    { name: 'Amazon Echo Show 10', description: 'Echo Show 10 com tela HD de 10.1", movimento automático e Alexa', type: ProductType.ACESSORIOS, brand: 'Amazon', price: 1799.00, rating: 4.7, stock: 60 },
    { name: 'Google Nest Hub Max', description: 'Nest Hub Max com tela HD de 10", Google Assistant e câmera de segurança', type: ProductType.ACESSORIOS, brand: 'Google', price: 1599.00, rating: 4.6, stock: 55 },
    { name: 'Câmera de Segurança Interna Wyze Cam v3', description: 'Câmera Wyze Cam v3 à prova d\'água com visão noturna colorida', type: ProductType.ACESSORIOS, brand: 'Wyze', price: 299.00, rating: 4.5, stock: 120 },
  ];

  // Combina a lista inicial com a lista adicional
  const products = [
    // Celulares
    {
      name: 'iPhone 15 Pro Max',
      description: 'Apple iPhone 15 Pro Max 256GB - Titânio Natural',
      type: ProductType.CELULAR,
      brand: 'Apple',
      price: 9499.99,
      rating: 4.9,
      stock: 50,
    },
    {
      name: 'Samsung Galaxy S24 Ultra',
      description: 'Samsung Galaxy S24 Ultra 512GB - Titanium Black',
      type: ProductType.CELULAR,
      brand: 'Samsung',
      price: 7999.99,
      rating: 4.8,
      stock: 75,
    },
    {
      name: 'Xiaomi 13T Pro',
      description: 'Xiaomi 13T Pro 512GB - Preto',
      type: ProductType.CELULAR,
      brand: 'Xiaomi',
      price: 3499.99,
      rating: 4.7,
      stock: 100,
    },

    // Notebooks
    {
      name: 'MacBook Pro 14"',
      description: 'MacBook Pro 14" M3 Pro 18GB 512GB - Space Gray',
      type: ProductType.NOTEBOOK,
      brand: 'Apple',
      price: 16999.99,
      rating: 4.9,
      stock: 30,
    },
    {
      name: 'Dell XPS 15',
      description: 'Dell XPS 15 Intel i7 32GB 1TB SSD RTX 4060',
      type: ProductType.NOTEBOOK,
      brand: 'Dell',
      price: 11999.99,
      rating: 4.7,
      stock: 45,
    },
    {
      name: 'Lenovo ThinkPad X1',
      description: 'Lenovo ThinkPad X1 Carbon Gen 11 i7 16GB 512GB',
      type: ProductType.NOTEBOOK,
      brand: 'Lenovo',
      price: 8999.99,
      rating: 4.6,
      stock: 60,
    },

    // TVs
    {
      name: 'Samsung QLED 65"',
      description: 'Smart TV Samsung QLED 65" 4K QN65Q80C',
      type: ProductType.TV,
      brand: 'Samsung',
      price: 5499.99,
      rating: 4.8,
      stock: 25,
    },
    {
      name: 'LG OLED 55"',
      description: 'Smart TV LG OLED 55" 4K OLED55C3',
      type: ProductType.TV,
      brand: 'LG',
      price: 4999.99,
      rating: 4.9,
      stock: 20,
    },

    // Hardware
    {
      name: 'AMD Ryzen 9 7950X',
      description: 'Processador AMD Ryzen 9 7950X 16-Core 5.7GHz',
      type: ProductType.HARDWARE,
      brand: 'AMD',
      price: 2899.99,
      rating: 4.8,
      stock: 80,
    },
    {
      name: 'NVIDIA RTX 4090',
      description: 'Placa de Vídeo NVIDIA GeForce RTX 4090 24GB',
      type: ProductType.HARDWARE,
      brand: 'NVIDIA',
      price: 12999.99,
      rating: 4.9,
      stock: 15,
    },
    {
      name: 'Corsair Vengeance 32GB',
      description: 'Memória RAM Corsair Vengeance DDR5 32GB (2x16GB) 6000MHz',
      type: ProductType.HARDWARE,
      brand: 'Corsair',
      price: 899.99,
      rating: 4.7,
      stock: 150,
    },

    // Periféricos
    {
      name: 'Logitech MX Master 3S',
      description: 'Mouse Logitech MX Master 3S Wireless',
      type: ProductType.PERIFERICOS,
      brand: 'Logitech',
      price: 599.99,
      rating: 4.8,
      stock: 200,
    },
    {
      name: 'Keychron K8 Pro',
      description: 'Teclado Mecânico Keychron K8 Pro Wireless',
      type: ProductType.PERIFERICOS,
      brand: 'Keychron',
      price: 899.99,
      rating: 4.7,
      stock: 120,
    },

    // Acessórios
    {
      name: 'AirPods Pro 2',
      description: 'Apple AirPods Pro 2ª Geração com USB-C',
      type: ProductType.ACESSORIOS,
      brand: 'Apple',
      price: 1899.99,
      rating: 4.9,
      stock: 180,
    },
    {
      name: 'Samsung T7 Shield 2TB',
      description: 'SSD Externo Samsung T7 Shield 2TB USB 3.2',
      type: ProductType.ACESSORIOS,
      brand: 'Samsung',
      price: 1199.99,
      rating: 4.8,
      stock: 95,
    },

    // Adiciona todos os produtos da segunda lista (com correção)
    ...additionalProducts
  ];
  // ----------------------------------------------------------------------------------

  for (const product of products) {
    const created = await prisma.product.create({
      data: product,
    });
    console.log(`✅ Created: ${created.name} - R$ ${created.price}`);
  }

  const allProducts = await prisma.product.findMany();
  console.log(`\n🎉 Successfully created ${allProducts.length} products!`);
  console.log('\n📦 Product IDs for testing:');
  allProducts.slice(0, 5).forEach((p) => {
    console.log(`   ${p.id} - ${p.name}`);
  });
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });