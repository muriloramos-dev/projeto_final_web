import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateCartDto } from './dto/create-cart.dto';
import { UpdateCartDto } from './dto/update-cart.dto';
import { PrismaService } from 'src/prisma/prisma.service';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

// Interface auxiliar para os dados do produto que você busca
interface ProductData {
  id: string;
  price: number;
  // Adicione outras propriedades do produto que você usa, como pricePix, priceCardInstallments
  pricePix?: number;
  priceCardInstallments?: number;
  // ...
}

@Injectable()
export class CartService {

  constructor(
    private readonly prisma: PrismaService,
    private readonly httpService: HttpService,
  ) { }

  // =============================================================
  // HELPER PRIVADO PARA RECALCULAR O VALOR TOTAL E ENRIQUECER ITENS
  // =============================================================
  private async recalculateAndEnrichCart(cartId: string): Promise<object> {
    const cart = await this.prisma.cart.findUnique({
      where: { id: cartId },
      include: { items: true },
    });

    if (!cart) {
      throw new NotFoundException(`Cart with ID ${cartId} not found`);
    }

    const productIds = cart.items.map(item => item.productId);

    let products: ProductData[] = [];
    try {
      const { data } = await firstValueFrom(
        this.httpService.post<ProductData[]>('http://localhost:8081/product/batch', {
          productIds,
        }),
      );
      products = data;
    } catch (error) {
      console.error('Error fetching products during recalculation:', error);
      throw new Error('Failed to fetch product details for recalculation');
    }

    let totalValue = 0;
    const productMap = new Map(products.map(p => [p.id, p]));
    
    // 1. Recalcula o valor
    for (const item of cart.items) {
      const product = productMap.get(item.productId);
      if (!product) {
        throw new NotFoundException(`Product with ID ${item.productId} not found`);
      }
      totalValue += Number(product.price) * item.quantity;
    }

    // 2. Atualiza o valor no DB
    await this.prisma.cart.update({
      where: { id: cartId },
      data: { totalValue },
    });
    
    // 3. Retorna o carrinho enriquecido
    const enrichedItems = cart.items.map(item => ({
      ...item,
      product: productMap.get(item.productId),
    }));

    return {
      ...cart,
      totalValue,
      items: enrichedItems,
    };
  }

  async addItemToActiveCart(userId: string, productId: string, quantity: number): Promise<object> {
    
    // 1. Busca o carrinho ativo do usuário
    const existingCart = await this.prisma.cart.findFirst({
        where: { userId: userId },
        orderBy: { createdAt: 'desc' }, 
        include: { items: true },
    });

    // 2. Se não houver carrinho, cria um novo
    if (!existingCart) {
        // Reutilizamos o método create existente
        return this.create({ items: [{ productId, quantity }] } as CreateCartDto, userId);
    }
    
    const cartId = existingCart.id;
    const existingItem = existingCart.items.find(item => item.productId === productId);

    if (existingItem) {
        // 3. Se o item existir, atualiza a quantidade
        const newQuantity = existingItem.quantity + quantity;
        
        // Reutilizamos o método updateCartItem
        return this.updateCartItem(cartId, productId, newQuantity);
    } else {
        // 4. Se o item não existir, cria um novo item no carrinho
        await this.prisma.cartItem.create({
            data: {
                cartId: cartId,
                productId: productId,
                quantity: quantity,
            },
        });
        // 5. Recalcula e retorna o carrinho enriquecido
        return this.recalculateAndEnrichCart(cartId);
    }
}

  // =============================================================


  async create(createCartDto: CreateCartDto, userId: string): Promise<object> {
    // ... Lógica de criação existente (inclusão de itens no banco de dados)
    console.log('Creating cart for user:', userId);
    console.log('Items:', JSON.stringify(createCartDto.items));

    const { items } = createCartDto;
    const productIds = items.map(item => item.productId);

    // Fetch products
    let products: ProductData[] = [];
    try {
      console.log('Fetching products from:', 'http://localhost:8081/product/batch');
      const { data } = await firstValueFrom(
        this.httpService.post<ProductData[]>('http://localhost:8081/product/batch', {
          productIds,
        }),
      );
      products = data;
      console.log('Products fetched:', products.length);
    } catch (error) {
      console.error('Error fetching products from product service', error);
      throw new Error('Failed to fetch product details');
    }

    // Calculate total value
    let totalValue = 0;
    const productMap = new Map(products.map(p => [p.id, p]));

    for (const item of items) {
      const product = productMap.get(item.productId);
      if (!product) {
        console.error(`Product with ID ${item.productId} not found in fetched products`);
        throw new NotFoundException(`Product with ID ${item.productId} not found`);
      }
      totalValue += Number(product.price) * item.quantity;
    }

    console.log('Total value calculated:', totalValue);

    // Create cart with items
    try {
      const cart = await this.prisma.cart.create({
        data: {
          userId: userId,
          items: {
            create: items,
          },
          totalValue,
        },
        include: {
          items: true,
        },
      });
      console.log('Cart created successfully:', cart.id);
      return cart;
    } catch (error: any) {
      console.error('Error creating cart in database:', error);
      // Removendo a lógica de escrita em arquivo para simplificar o código
      throw new Error(`Database Error: ${error.message}`);
    }
  }

  // NOVO: Busca o carrinho ativo pelo ID do usuário
  async findOneByUserId(userId: string): Promise<object | null> {
    const cart = await this.prisma.cart.findFirst({
      where: {
        userId: userId,
        // Adicione aqui a condição para carrinho 'ativo' se você a tiver (ex: status: 'ACTIVE')
      },
      orderBy: { createdAt: 'desc' }, // Busca o mais recente
      include: {
        items: true,
      },
    });

    if (!cart) {
      // É importante não lançar NotFoundException aqui, mas sim retornar um indicador de que não há carrinho
      // O Controller pode lançar 404 se o retorno for null/vazio, ou você pode retornar um objeto com status.
      return null; 
    }

    // Reutiliza a lógica existente de findOne para enriquecer os itens
    return await this.findOne(cart.id); 
  }

  // ... (findAll e findOne inalterados)
  async findAll(page: number = 1, limit: number = 10) {
    const skip = (page - 1) * limit;

    return await this.prisma.cart.findMany({
      skip,
      take: limit,
      include: {
        items: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async findOne(id: string) {
    const cart = await this.prisma.cart.findUnique({
      where: { id },
      include: {
        items: true,
      },
    });

    if (!cart) {
      throw new NotFoundException(`Cart with ID ${id} not found`);
    }

    // Fetch product details for each item
    const productIds = cart.items.map(item => item.productId);
    
    let products: any[] = [];
    try {
      const { data } = await firstValueFrom(
        this.httpService.post<any[]>('http://localhost:8081/product/batch', {
          productIds,
        }),
      );
      products = data;
    } catch (error) {
      console.error('Error fetching products', error);
      // Return cart without product details if service is unavailable
      return cart;
    }

    // Enrich cart items with product details
    const productMap = new Map(products.map(p => [p.id, p]));
    const enrichedItems = cart.items.map(item => ({
      ...item,
      product: productMap.get(item.productId),
    }));

    return {
      ...cart,
      items: enrichedItems,
    };
  }

  async update(id: string, updateCartDto: UpdateCartDto) {
    // ... Lógica de atualização existente (substitui todos os itens)
    // Manteremos esta função para a lógica de substituição completa de itens.
    // Lembre-se: o helper recalculateAndEnrichCart simplificaria grande parte disso.
    
    // Check if cart exists
    const existingCart = await this.prisma.cart.findUnique({
      where: { id },
      include: { items: true },
    });

    if (!existingCart) {
      throw new NotFoundException(`Cart with ID ${id} not found`);
    }

    const { items } = updateCartDto;

    // If items are being updated, recalculate total value
    if (items && items.length > 0) {
      const productIds = items.map(item => item.productId);

      let products: ProductData[] = [];
      try {
        const { data } = await firstValueFrom(
          this.httpService.post<ProductData[]>('http://localhost:8081/product/batch', {
            productIds,
          }),
        );
        products = data;
      } catch (error) {
        console.error('Error fetching products', error);
        throw new Error('Failed to fetch product details');
      }

      // Calculate new total value
      let totalValue = 0;
      const productMap = new Map(products.map(p => [p.id, p]));

      for (const item of items) {
        const product = productMap.get(item.productId);
        if (!product) {
          throw new NotFoundException(`Product with ID ${item.productId} not found`);
        }
        totalValue += Number(product.price) * item.quantity;
      }

      // Delete existing items and create new ones
      await this.prisma.cartItem.deleteMany({
        where: { cartId: id },
      });

      return await this.prisma.cart.update({
        where: { id },
        data: {
          totalValue,
          items: {
            create: items,
          },
        },
        include: {
          items: true,
        },
      });
    }

    return existingCart;
  }

  // NOVO: Atualiza a quantidade de um item no carrinho
  async updateCartItem(cartId: string, productId: string, quantity: number): Promise<object> {
    const existingItem = await this.prisma.cartItem.findFirst({
      where: { cartId, productId },
    });

    if (!existingItem) {
      throw new NotFoundException(`Product ID ${productId} not found in Cart ID ${cartId}`);
    }

    if (quantity <= 0) {
      return this.removeCartItem(cartId, productId);
    }
    
    // Atualiza a quantidade
    await this.prisma.cartItem.update({
      where: { id: existingItem.id },
      data: { quantity },
    });

    // Recalcula o valor total e retorna o carrinho enriquecido
    return this.recalculateAndEnrichCart(cartId);
  }

  // NOVO: Remove um item específico do carrinho
  async removeCartItem(cartId: string, productId: string): Promise<object> {
    const existingItem = await this.prisma.cartItem.findFirst({
      where: { cartId, productId },
    });

    if (!existingItem) {
      throw new NotFoundException(`Product ID ${productId} not found in Cart ID ${cartId}`);
    }

    // Remove o item
    await this.prisma.cartItem.delete({
      where: { id: existingItem.id },
    });

    // Recalcula o valor total e retorna o carrinho enriquecido
    return this.recalculateAndEnrichCart(cartId);
  }

  // NOVO: Limpa todos os itens do carrinho (sem deletar o carrinho)
  async clearCart(cartId: string): Promise<void> {
    await this.prisma.cartItem.deleteMany({
      where: { cartId },
    });
    
    // Zera o valor total
    await this.prisma.cart.update({
      where: { id: cartId },
      data: { totalValue: 0 },
    });
  }

  // ... (remove inalterado)
  async remove(id: string) {
    // Check if cart exists
    const cart = await this.prisma.cart.findUnique({
      where: { id },
    });

    if (!cart) {
      throw new NotFoundException(`Cart with ID ${id} not found`);
    }

    // Delete cart (cascade will delete items)
    await this.prisma.cart.delete({
      where: { id },
    });

    return { message: `Cart with ID ${id} successfully deleted` };
  }
}