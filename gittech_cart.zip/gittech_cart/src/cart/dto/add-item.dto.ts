// File: src/cart/dto/add-item.dto.ts

import { IsNotEmpty, IsString, IsInt, IsPositive } from 'class-validator';

export class AddItemDto {
  @IsString()
  @IsNotEmpty()
  productId: string;

  @IsInt()
  @IsPositive()
  quantity: number;
}