import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Query, ParseIntPipe, HttpCode, HttpStatus, Inject } from '@nestjs/common';
import { CartService } from './cart.service';
import { CreateCartDto } from './dto/create-cart.dto';
import { UpdateCartDto } from './dto/update-cart.dto';
import { AddItemDto } from './dto/add-item.dto';
import { ClientProxy } from '@nestjs/microservices';

@Controller('cart')
export class CartController {
  constructor(private readonly cartService: CartService, @Inject("CART_SERVICE") private readonly client: ClientProxy) { }

  @Post("/:userId")
  create(@Body() createCartDto: CreateCartDto, @Param("userId") userId: string) {
    return this.cartService.create(createCartDto, userId);
  }

  @Get()
  findAll(
    @Query('page', new ParseIntPipe({ optional: true })) page?: number,
    @Query('limit', new ParseIntPipe({ optional: true })) limit?: number,
  ) {
    return this.cartService.findAll(page, limit);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.cartService.findOne(id);
  }

  @Post('item/:userId')
  @HttpCode(HttpStatus.OK)
  async addItem(
    @Param('userId') userId: string,
    // O DTO deve conter productId e quantity
    @Body() addItemDto: AddItemDto,
  ) {
    // Chama o novo método que lida com a criação ou atualização
    return this.cartService.addItemToActiveCart(
      userId,
      addItemDto.productId,
      addItemDto.quantity,
    );
  }

  @Delete(':id/item/:productId')
  @HttpCode(HttpStatus.OK) // Retorna o carrinho atualizado com status 200 OK
  async removeCartItem(
    @Param('id') cartId: string,
    @Param('productId') productId: string,
  ) {
    // Chama o serviço para remover o item, que já lida com o recálculo e enriquecimento
    return this.cartService.removeCartItem(cartId, productId);
  }

  @Get('user/:userId') // Rota: GET /cart/user/:userId
  findOneByUserId(@Param('userId') userId: string) {
    // Você precisa ter um método findOneByUserId no CartService para buscar o carrinho ativo.
    return this.cartService.findOneByUserId(userId);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateCartDto: UpdateCartDto) {
    return this.cartService.update(id, updateCartDto);
  }

  @Get("/test/:teste")
  test(@Param("teste") teste: string) {
    this.client.send("product", teste);
  }

  @Patch(':id/item')
  @HttpCode(HttpStatus.OK)
  async updateCartItem(
    @Param('id') cartId: string,
    // O Body contém { productId, quantity }
    @Body() updateItemDto: { productId: string, quantity: number },
  ) {
    // Chama o serviço, que já lida com o recálculo e enriquecimento
    return this.cartService.updateCartItem(
      cartId,
      updateItemDto.productId,
      updateItemDto.quantity
    );
  }

  @Delete(':id/clear')
  @HttpCode(HttpStatus.NO_CONTENT) // Retorna 204 No Content se for bem-sucedido
  async clearCart(@Param('id') id: string) {
    // Chama o serviço para limpar todos os itens
    await this.cartService.clearCart(id);

    // Retornamos void para 204 No Content
    // Se você preferir retornar 200 OK com uma mensagem, remova @HttpCode e retorne um objeto:
    // return { message: `Cart with ID ${id} successfully cleared.` };
  }
}
