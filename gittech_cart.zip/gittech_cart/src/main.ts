import 'dotenv/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import cookieParser from 'cookie-parser';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(cookieParser());
  const config = new DocumentBuilder().setTitle('Gittech Cart').build();

  const documentFactory = () => SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, documentFactory);

  app.connectMicroservice({
    transport: Transport.RMQ,
    options: {
      urls: [process.env.AMQP_URL || 'amqp://admin:admin@localhost:5672'],
      queue: 'product_queue',
      queueOptions: {
        durable: false,
      },
    },
  });

  app.enableCors({
    origin: 'http://localhost:3000',
    credentials: true,
  });

  await app.startAllMicroservices();
  await app.listen(process.env.PORT ?? 3001);
}
bootstrap();
