import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export const UserId = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): string | null => {
    const request = ctx.switchToHttp().getRequest();
    // O AuthGuard anexa o payload do usuário (incluindo 'sub') ao objeto de requisição
    const user = request.user;
    return user ? user.sub : null;
  },
);
