import { PrismaClient } from '../generated/prisma';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding cart database...');
  console.log('⚠️  Note: You need to provide actual User IDs and Product IDs');
  console.log('   Run the user and product seeds first, then update this file with real IDs');
  
  // Example cart data - UPDATE THESE IDs WITH REAL ONES FROM YOUR DATABASE
  // You can get these by:
  // 1. Running user seed first
  // 2. Running product seed 
  // 3. Copying the printed IDs and pasting here
  
  const exampleCarts = [
    {
      userId: 'USER_ID_1', // Replace with actual user ID from user database
      totalValue: 10099.98,
      items: [
        {
          productId: 'PRODUCT_ID_IPHONE', // Replace with actual iPhone product ID
          quantity: 1,
        },
        {
          productId: 'PRODUCT_ID_AIRPODS', // Replace with actual AirPods product ID
          quantity: 1,
        },
      ],
    },
    {
      userId: 'USER_ID_2', // Replace with actual user ID
      totalValue: 13899.98,
      items: [
        {
          productId: 'PRODUCT_ID_MACBOOK', // Replace with actual MacBook product ID
          quantity: 1,
        },
      ],
    },
  ];

  console.log('\n📝 To populate cart database:');
  console.log('1. Run user seed: cd gittech_user && npm run seed');
  console.log('2. Run product seed: cd gittech_product && npm run seed');
  console.log('3. Copy the printed IDs');
  console.log('4. Update gittech_cart/prisma/seed.ts with real IDs');
  console.log('5. Run: cd gittech_cart && npm run seed');
  console.log('\n💡 Or use the API to create carts via POST /cart endpoint');

  // Uncomment and update IDs to actually create carts
  /*
  for (const cartData of exampleCarts) {
    const cart = await prisma.cart.create({
      data: {
        userId: cartData.userId,
        totalValue: cartData.totalValue,
        items: {
          create: cartData.items,
        },
      },
      include: {
        items: true,
      },
    });
    console.log(`✅ Created cart ${cart.id} for user ${cart.userId}`);
  }
  */
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
