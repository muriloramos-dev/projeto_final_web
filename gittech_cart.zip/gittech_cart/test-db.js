
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient({
    datasources: {
        db: {
            url: "mysql://root:123@localhost:3306/gittech_cart"
        }
    }
});

async function main() {
    try {
        console.log('Connecting to database...');
        await prisma.$connect();
        console.log('Connected successfully!');

        console.log('Listing carts...');
        const carts = await prisma.cart.findMany();
        console.log('Carts found:', carts.length);

    } catch (e) {
        console.error('Error connecting to database:', e);
    } finally {
        await prisma.$disconnect();
    }
}

main();
