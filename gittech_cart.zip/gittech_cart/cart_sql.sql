create table Cart (
	cart_id CHAR(36),
    total_value FLOAT NOT NULL,
    user_id CHAR(36) NOT NULL,
    PRIMARY KEY(cart_id),
    FOREIGN KEY (user_id) REFERENCES UserEntity(user_id)
);